package com.bdd.stepdefinition;
import com.bdd.step.AutomatizacionStep;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class AutomatizacionStepDefinition {
    @Steps
    private AutomatizacionStep automatizacionStep;
    @Given("^Cargar la pagina de Yourlogo")

        public void cargarPaginayourlogo(){
        automatizacionStep.cargarPaginawebyourlogo();

    }

    @And("^Iniciar sesión con usuario \"([^\"]*)\" y password \"([^\"]*)\"$")
    public void iniciarSesiónConUsuarioYPassword(String arg0, String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        automatizacionStep.ingresarCredenciales(arg0, arg1);// Write code here that turns the phrase above into concrete actions

    }


    @When("^Agregar los productos \"([^\"]*)\" y \"([^\"]*)\" al carrito$")
    public void agregarLosProductosYAlCarrito() throws Throwable {

    }

    @Then("^validar que el carrito tenga (\\d+) productos$")
    public void validarQueElCarritoTengaProductos() {

    }
}
