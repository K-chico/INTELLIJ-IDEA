package com.bdd.page;

import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

@DefaultUrl("https://www.saucedemo.com/ ")


public class AutomatizacionPage extends PageObject {
    WebDriver driver;
    public void ingresarUsuario(String arg0) {
        $("#user-name").sendKeys(arg0);
    }

    public void ingresarPassword(String arg1) {
        $("#password").sendKeys(arg1);
    }

    public void hacerClickEnLogin() {
        $("#login-button").click();

    }



}
