package com.bdd.step;

import com.bdd.page.AutomatizacionPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class AutomatizacionStep extends ScenarioSteps {

    private AutomatizacionPage automatizacionPage;
    public void cargarPaginawebyourlogo() {
        automatizacionPage.open();
        getDriver().manage().window().maximize();

    }

    public void ingresarCredenciales(String arg0, String arg1) {
        automatizacionPage.ingresarUsuario(arg0);
        automatizacionPage.ingresarPassword(arg1);
        automatizacionPage.hacerClickEnLogin();
    }



}
